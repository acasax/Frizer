mobiscroll.setOptions({
    theme: 'ios',
    themeVariant: 'light'
});

mobiscroll.datepicker('#date', {
    controls: ['calendar', 'time'],
    display: 'inline'
});